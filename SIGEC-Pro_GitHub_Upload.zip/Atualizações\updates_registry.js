window.SIGEC_AVAILABLE_UPDATES = [
  {
    "packageName": "SIGEC_V1.1",
    "version": "SIGEC_V1.1",
    "createdAt": "2026-08-09T21:44:00.000Z",
    "system": "SIGEC-Pro",
    "notes": "Pacote de atualização SIGEC-Pro V1.1",
    "database": {
      "clientes": [],
      "contactos": [],
      "projetos": [],
      "interacoes": [],
      "interacoesProjetos": [],
      "deletedProjectIds": []
    }
  },
  {
    "packageName": "SIGEC_V1.2",
    "version": "SIGEC_V1.2",
    "createdAt": "2026-08-09T22:15:00.000Z",
    "system": "SIGEC-Pro",
    "notes": "Pacote de atualização SIGEC-Pro V1.2",
    "database": {
      "clientes": [],
      "contactos": [],
      "projetos": [],
      "interacoes": [],
      "interacoesProjetos": [],
      "deletedProjectIds": []
    }
  },
  {
    "packageName": "SIGEC_V1.3",
    "version": "SIGEC_V1.3",
    "createdAt": "2026-08-09T22:28:00.000Z",
    "system": "SIGEC-Pro",
    "notes": "Pacote de atualização SIGEC-Pro V1.3",
    "database": {
      "clientes": [],
      "contactos": [],
      "projetos": [],
      "interacoes": [],
      "interacoesProjetos": [],
      "deletedProjectIds": []
    }
  },
  {
    "packageName": "SIGEC_V1.4",
    "version": "SIGEC_V1.4",
    "createdAt": "2026-08-09T22:35:00.000Z",
    "system": "SIGEC-Pro",
    "notes": "Pacote de atualização SIGEC-Pro V1.4",
    "database": {
      "clientes": [],
      "contactos": [],
      "projetos": [],
      "interacoes": [],
      "interacoesProjetos": [],
      "deletedProjectIds": []
    }
  },
  {
    "packageName": "SIGEC_V1.5",
    "version": "SIGEC_V1.5",
    "createdAt": "2026-08-10T08:35:00.000Z",
    "system": "SIGEC-Pro",
    "notes": "Pacote de atualização SIGEC-Pro V1.5 - Consolidação de Clientes, Contactos e Projetos (SmartBus Huawei, Unidade Móvel Bancária e Estratégia 2040)",
    "database": {
      "clientes": [
        {
          "id": "cli-imp-001",
          "tipoCliente": "Privado",
          "nome": "EDP",
          "contribuinte": "500000034",
          "direcao1": "Avenida 24 de Julho, n.º 12, 1249-300 Lisboa, Portugal",
          "codigoPostal": "1249-300",
          "localidade": "Lisboa",
          "telefone": "+351 210 012 500",
          "email": "rui.cabrita@edp.com",
          "createdAt": "2026-07-31T16:30:00.000Z"
        },
        {
          "id": "cli-imp-005",
          "tipoCliente": "Privado",
          "nome": "Huawei Portugal",
          "contribuinte": "503998877",
          "direcao1": "Avenida D. João II, Lote 1.07.21, Parque das Nações",
          "codigoPostal": "1990-096",
          "localidade": "Lisboa",
          "telefone": "+351 211 200 800",
          "email": "contacto.pt@huawei.com",
          "createdAt": "2026-07-31T16:30:00.000Z"
        },
        {
          "id": "cli-imp-084",
          "tipoCliente": "Público",
          "nome": "CCDR-N (Comissão de Coordenação e Desenvolvimento Regional do Norte)",
          "contribuinte": "502334455",
          "direcao1": "Rua Rainha Dona Estefânia, 251",
          "codigoPostal": "4150-304",
          "localidade": "Porto",
          "telefone": "+351 226 086 300",
          "email": "geral@ccdr-n.pt",
          "createdAt": "2026-07-31T16:30:00.000Z"
        },
        {
          "id": "cli-imp-085",
          "tipoCliente": "Privado",
          "nome": "BCN (Banco Cabo-Verdiano de Negócios)",
          "contribuinte": "509887766",
          "direcao1": "Avenida Amílcar Cabral, C.P. 544",
          "codigoPostal": "7600-000",
          "localidade": "Praia",
          "telefone": "+238 260 36 00",
          "email": "marketing@bcn.cv",
          "createdAt": "2026-07-31T16:30:00.000Z"
        }
      ],
      "contactos": [],
      "projetos": [
        {
          "id": "proj-camp-001",
          "clienteId": "cli-imp-005",
          "nome": "Campanha SmartBus Huawei PT - Rota Escolar e Cidadania Digital",
          "tipo": "Exposição Itinerante",
          "dataInicio": "2026-02-01",
          "dataFim": "2026-06-30",
          "estado": "Adjudicado",
          "viatura": "Huawei SmartBus PT",
          "matricula": "99-HB-22",
          "obs": "Itineração por escolas de Braga, Porto, Gaia, Aveiro, Viseu, Évora, Portimão e Torres Vedras.",
          "createdAt": "2026-07-31T17:00:00.000Z"
        },
        {
          "id": "proj-banc-001",
          "clienteId": "cli-imp-085",
          "nome": "Projeto Unidade Móvel Bancária - Atendimento Financeiro Itinerante",
          "tipo": "Ação Comercial",
          "dataInicio": "2026-03-01",
          "dataFim": "2026-11-30",
          "estado": "Em Curso",
          "viatura": "Unidade Móvel Bancária BCN 01",
          "matricula": "UB-20-BC",
          "obs": "Serviço móvel de atendimento bancário e inclusão financeira itinerante em regiões sem balcão fixo.",
          "createdAt": "2026-07-31T17:30:00.000Z"
        },
        {
          "id": "proj-estrat-2040",
          "clienteId": "cli-imp-084",
          "nome": "Projeto Estratégia 2040 - Roteiro de Inovação e Futuro Regional",
          "tipo": "Prospeção / Eventos",
          "dataInicio": "2026-01-15",
          "dataFim": "2026-12-31",
          "estado": "Adjudicado",
          "viatura": "Unidade Móvel Estratégia 2040",
          "matricula": "EST-20-40",
          "obs": "Roteiro itinerante de consulta pública e dinamização da Estratégia 2040 para o desenvolvimento territorial.",
          "createdAt": "2026-07-31T17:45:00.000Z"
        }
      ],
      "interacoes": [],
      "interacoesProjetos": [],
      "deletedProjectIds": []
    }
  }
];
